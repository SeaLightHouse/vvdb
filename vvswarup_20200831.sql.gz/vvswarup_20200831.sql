-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 31, 2020 at 09:40 AM
-- Server version: 5.7.18-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vvswarup`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `account_id` int(11) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `account_number` varchar(100) NOT NULL,
  `account_status` tinyint(4) NOT NULL,
  `special_account_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `account_name`, `account_number`, `account_status`, `special_account_id`) VALUES
(1, 'ATM Fill', '102300-902-000--RGL', 1, 0),
(2, 'ATM Return', '102300-902-000--RGL', 1, 0),
(3, 'Change Order', '100425-902-000--RGL', 1, 0),
(4, 'Deposit Released', '100425-902-000--RGL', 1, 0),
(5, 'Vending Machine Revenue', '460000-902-650--RGL', 1, 0),
(6, 'Found Money', '469500-902-500--RGL', 1, 0),
(7, 'Kiosk 1 Fill', '102301-902-000--RGL', 1, 0),
(8, 'Kiosk 1 Return', '102301-902-000--RGL', 1, 0),
(9, 'Kiosk 2 Fill', '102301-902-000--RGL', 1, 0),
(10, 'Kiosk 2 Return', '102301-902-000--RGL', 1, 0),
(11, 'Misc Disbursement', '126027-902-000--RGL', 1, 0),
(12, 'Misc Receipt', '125013-902-000--RGL', 1, 0),
(13, 'Cage Banks Returned', '102500-902-000--RGL', 1, 0),
(14, 'Soft Count Gaming Machine Drop', '123100-902-000--RGL', 1, 0),
(15, 'Test Money', '500100-902-500-YCZZZ-RGL', 1, 0),
(16, 'Tips- Cashier Use Only', '210400-902-000--RGL', 1, 0),
(17, 'Tips- Vault Use Only', '210400-902-000--RGL', 1, 0),
(18, '1042 Taxes Withheld', '260001-902-000--RGL', 1, 0),
(19, 'Amex', '120325-902-000--RGL', 1, 0),
(20, 'Concession Banks Disbursed', '102500-902-000--RGL', 1, 0),
(21, 'Concession Banks Returned', '102500-902-000--RGL', 1, 0),
(22, 'Cage Bank Disbursed', '102500-902-000--RGL', 1, 0),
(23, 'Sales', '100100-902-000--RGL', 1, 0),
(24, 'Promotions', '534349-902-600--RGL', 1, 0),
(25, 'Unscanned Tickets', '500100-902-500-YCZZZ-RGL', 1, 0),
(26, 'Voided Tickets', '500100-902-500-YCZZZ-RGL', 1, 0),
(27, 'CCA Credit  Sales', '120326-902-000--RGL', 1, 0),
(28, 'CCA Debit Sales', '120326-902-000--RGL', 1, 0),
(29, 'Discover', '120325-902-000--RGL', 1, 0),
(30, 'E Checks', '120335-902-000--RGL', 1, 0),
(31, 'Cancel Credit', '500100-902-500-YCZZZ-RGL', 1, 0),
(32, 'W2G Taxes Withheld', '260000-902-000--RGL', 1, 0),
(33, 'Jackpots', '500100-902-500-YCZZZ-RGL', 1, 0),
(34, 'Kiosk Coin Tickets Issued', '454400-902-300--RGL', 1, 0),
(35, 'Kiosk Short Pay', '102301-902-000--RGL', 1, 0),
(36, 'Machine Tickets', '500100-902-500-YCZZZ-RGL', 1, 0),
(37, 'Manual Payouts', '500100-902-500-YCZZZ-RGL', 1, 0),
(38, 'Cash Advance', '120326-902-000--RGL', 1, 0),
(39, 'Handpays', '500100-902-500-YCZZZ-RGL', 1, 0),
(40, 'Mastercard', '120325-902-000--RGL', 1, 0),
(41, 'Visa', '120325-902-000--RGL', 1, 0),
(42, 'Variance', '531900-902-300--RGL', 1, 1),
(43, 'Vault Cash', '102600-902-000--RGL', 1, 2),
(44, 'Tribal Tax', '212600-902-000--RGL', 1, 0),
(45, 'State Tax', '213050-902-000--RGL', 1, 0),
(46, 'Sales-Food and Beverage', '453500-902-650--RGL', 1, 0),
(47, 'Sales-Beer', '460500-675-000--RGL', 1, 0),
(48, 'Sales-Liquor', '453550-902-675--RGL', 1, 0),
(49, 'Sales-Tobacco', '469100-902-625--RGL', 1, 0),
(50, 'Sales-Miscellaneous', '453003-902-600--RGL', 1, 0),
(51, 'Marketing Discounts', '534370-902-600--RGL', 1, 0),
(52, 'Open $ Discount', '505900-902-650--RGL', 1, 0),
(53, 'Employee Discount', '505800-902-150--RGL', 1, 0),
(54, 'Vending', '506400-902-625--RGL', 1, 0),
(55, 'Tribal Charge', '891000-902-800--RGL', 1, 0),
(56, 'Employee Charge', '534500-902-150--RGL', 1, 0),
(57, 'Comps', '534372-902-600--RGL', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_log`
--

CREATE TABLE `admin_log` (
  `admin_log_id` int(11) NOT NULL,
  `record_id` int(11) NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `admin_category_id` int(11) NOT NULL,
  `log_comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin_log_category`
--

CREATE TABLE `admin_log_category` (
  `admin_log_category_id` int(11) NOT NULL,
  `admin_category` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_log_category`
--

INSERT INTO `admin_log_category` (`admin_log_category_id`, `admin_category`) VALUES
(1, 'Users'),
(2, 'Data Items'),
(3, 'Forms'),
(4, 'Banks'),
(5, 'Transactions'),
(6, 'Accounts'),
(7, 'System Settings'),
(8, 'Backups'),
(10, 'Auto Closed Bank Log'),
(11, 'Bank Category Log');

-- --------------------------------------------------------

--
-- Table structure for table `audit_activity`
--

CREATE TABLE `audit_activity` (
  `audit_activity_id` int(11) NOT NULL,
  `audit_instance_id` int(11) NOT NULL,
  `main_bank_instance_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` varchar(1000) NOT NULL,
  `documentation` varchar(50) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `export_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `audit_activity_instance`
--

CREATE TABLE `audit_activity_instance` (
  `audit_activity_instance_id` int(11) NOT NULL,
  `audit_activity_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `data_item_id` int(11) NOT NULL,
  `data_item_value` decimal(14,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `audit_instance`
--

CREATE TABLE `audit_instance` (
  `audit_instance_id` int(11) NOT NULL,
  `bank_instance_id` int(11) NOT NULL,
  `locked_user_id` int(11) NOT NULL,
  `audit_status` tinyint(1) NOT NULL,
  `audit_variance_amount` decimal(14,2) NOT NULL,
  `game_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `exported` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `log_id` int(11) NOT NULL,
  `event_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log_message` varchar(500) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(11) NOT NULL,
  `bank_level` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `receipt_form_id` int(11) NOT NULL,
  `receipt_account` varchar(100) NOT NULL,
  `disburse_form_id` int(11) NOT NULL,
  `disburse_account` varchar(100) NOT NULL,
  `variance_range` float NOT NULL,
  `bank_category_id` int(11) NOT NULL,
  `default_values` tinyint(1) NOT NULL,
  `default_override` tinyint(1) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `report_exclude` tinyint(4) NOT NULL,
  `allow_zero` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `bank_level`, `bank_name`, `receipt_form_id`, `receipt_account`, `disburse_form_id`, `disburse_account`, `variance_range`, `bank_category_id`, `default_values`, `default_override`, `status`, `report_exclude`, `allow_zero`) VALUES
(1, 1, 'Main Bank', 6, '9', 6, '9', 5, 1, 0, 0, 1, 0, 0),
(2, 3, 'Cage Cashier', 2, '2', 1, '3', 25, 2, 0, 0, 0, 0, 0),
(3, 3, 'Cafe Bank $750', 10, '21', 1, '20', 25, 4, 1, 0, 1, 0, 0),
(4, 3, 'Bar Bank (Supervisor)', 10, '', 1, '', 5, 4, 1, 1, 0, 0, 0),
(26, 3, 'Event Bank', 10, '', 1, '', 5, 4, 0, 0, 0, 0, 0),
(27, 3, 'Cafe Bank $500', 10, '21', 1, '20', 25, 4, 1, 1, 1, 0, 0),
(28, 3, 'Cage Cashier $10,000', 2, '13', 1, '22', 25, 2, 1, 1, 1, 0, 0),
(29, 3, 'Cage Cashier $5,000', 2, '13', 1, '22', 25, 2, 1, 1, 1, 0, 0),
(30, 3, 'Cage Cashier $25,000', 2, '13', 1, '22', 25, 2, 1, 1, 1, 0, 0),
(31, 3, 'Cage Cashier $15,000', 2, '13', 1, '22', 25, 2, 1, 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bank_activity`
--

CREATE TABLE `bank_activity` (
  `request_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `request_status` int(11) NOT NULL,
  `request_type` int(11) NOT NULL,
  `requested_user_id` int(11) NOT NULL,
  `verified` tinyint(1) NOT NULL,
  `responded_user_id` int(11) NOT NULL,
  `responding_bank_instance_id` int(11) NOT NULL,
  `documentation` varchar(500) NOT NULL,
  `transaction_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_activity_instance`
--

CREATE TABLE `bank_activity_instance` (
  `request_id` int(11) NOT NULL,
  `data_item_id` int(11) NOT NULL,
  `data_item_value` decimal(14,2) NOT NULL,
  `item_order` int(11) NOT NULL,
  `form_section` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_activity_log`
--

CREATE TABLE `bank_activity_log` (
  `bank_activity_log_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `source_bank_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_to` int(11) NOT NULL,
  `log_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_category`
--

CREATE TABLE `bank_category` (
  `bank_category_id` int(11) NOT NULL,
  `bank_category_name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_category`
--

INSERT INTO `bank_category` (`bank_category_id`, `bank_category_name`, `status`) VALUES
(1, 'Main Bank', 1),
(2, 'Cage', 1),
(3, 'F&B', 1),
(4, 'Bar', 1),
(5, 'Bingo', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bank_default_detail`
--

CREATE TABLE `bank_default_detail` (
  `bank_id` int(11) NOT NULL,
  `data_item_id` int(11) NOT NULL,
  `data_item_value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_instance`
--

CREATE TABLE `bank_instance` (
  `instance_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bank_level` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `receipt_form_id` int(11) NOT NULL,
  `disburse_form_id` int(11) NOT NULL,
  `variance_range` float NOT NULL,
  `bank_status` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_category_id` int(11) NOT NULL,
  `variance_override` varchar(100) NOT NULL,
  `variance_override_user_id` varchar(100) NOT NULL,
  `variance_override_comment` varchar(500) NOT NULL,
  `variance_amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_instance_detail`
--

CREATE TABLE `bank_instance_detail` (
  `instance_id` int(11) NOT NULL,
  `data_item_id` int(11) NOT NULL,
  `data_item_value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_instance_log`
--

CREATE TABLE `bank_instance_log` (
  `bank_instance_id` int(11) NOT NULL,
  `open_date` datetime NOT NULL,
  `close_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_instance_meta_data`
--

CREATE TABLE `bank_instance_meta_data` (
  `bank_instance_id` int(11) NOT NULL,
  `meta_id` int(11) NOT NULL,
  `value` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_user`
--

CREATE TABLE `bank_user` (
  `bank_instance_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_override_user_id` int(11) NOT NULL,
  `bank_override_comment` varchar(500) NOT NULL,
  `secondary` tinyint(4) NOT NULL,
  `verified_open` tinyint(4) NOT NULL,
  `verified_closed` tinyint(4) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `current_flagged`
--

CREATE TABLE `current_flagged` (
  `in_total` float(15,2) NOT NULL,
  `out_total` float(15,2) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer` varchar(500) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `ssn` varchar(100) NOT NULL,
  `customer_image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `data_item`
--

CREATE TABLE `data_item` (
  `data_item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `item_increment` float(8,2) NOT NULL,
  `item_status` tinyint(4) NOT NULL,
  `require_documentation` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_item`
--

INSERT INTO `data_item` (`data_item_id`, `item_name`, `category_id`, `account_id`, `item_increment`, `item_status`, `require_documentation`) VALUES
(1, 'Ones ($1)', 1, 43, 1.00, 1, 1),
(2, 'Twos ($2)', 1, 43, 2.00, 1, 1),
(3, 'Fives ($5)', 1, 43, 5.00, 1, 1),
(4, 'Tens ($10)', 1, 43, 10.00, 1, 1),
(5, 'Twenties ($20)', 1, 43, 20.00, 1, 1),
(6, 'Fifties ($50)', 1, 43, 50.00, 1, 1),
(7, 'Hundreds ($100)', 1, 43, 100.00, 1, 1),
(8, 'Dollars ($1.00)', 1, 43, 1.00, 1, 1),
(9, 'Fifty-Cent ($0.50)', 1, 43, 0.50, 1, 1),
(10, 'Quarters ($0.25)', 1, 43, 0.25, 1, 1),
(11, 'Dimes ($0.10)', 1, 43, 0.10, 1, 1),
(12, 'Nickels ($0.05)', 1, 43, 0.05, 1, 1),
(13, 'Pennies ($0.01)', 1, 43, 0.01, 1, 1),
(14, 'Other Coin', 1, 43, 0.01, 1, 1),
(15, '500.00', 3, 0, 500.00, 1, 1),
(16, '100.00', 3, 0, 100.00, 1, 1),
(17, '25.00', 3, 0, 25.00, 1, 1),
(18, '5.00', 3, 0, 5.00, 1, 1),
(19, '1.00', 3, 0, 1.00, 1, 1),
(20, '0.25', 3, 0, 0.25, 1, 1),
(21, 'Cash Advances', 2, 38, 0.01, 1, 1),
(22, 'E-checks', 2, 30, 0.01, 1, 1),
(23, 'Promotions', 2, 24, 0.01, 1, 1),
(24, 'Machine Tickets', 2, 36, 0.01, 1, 1),
(25, 'Jackpots', 2, 33, 0.01, 1, 1),
(26, 'Handpays', 2, 39, 0.01, 1, 1),
(27, 'Manual Payouts', 2, 37, 0.01, 1, 1),
(28, 'Mutilated', 1, 43, 0.01, 1, 1),
(29, 'NNC 5.00', 3, 0, 5.00, 1, 1),
(30, 'Net Sales - after discounts', 4, 0, 0.01, 1, 1),
(31, 'Unscanned Tickets', 2, 25, 0.01, 1, 1),
(32, 'Misc. Checks', 5, 43, 0.01, 1, 1),
(33, 'Global Checks', 5, 0, 0.01, 1, 1),
(34, 'Tribal Checks', 5, 0, 0.01, 1, 1),
(35, 'Checks for Deposit', 5, 43, 0.01, 1, 1),
(36, 'Tips', 2, 0, 0.01, 1, 1),
(38, 'Deposits On Hold', 5, 0, 0.01, 1, 1),
(39, 'Checks not for Deposit', 2, 0, 0.01, 1, 1),
(40, 'Banks On Hold', 1, 0, 0.01, 1, 1),
(41, 'Jackpot Taxes Withheld', 4, 0, 0.01, 1, 1),
(42, 'Visa', 2, 41, 0.01, 1, 1),
(43, 'Discover', 2, 29, 0.01, 1, 1),
(44, 'American Express', 2, 19, 0.01, 1, 1),
(45, 'AUDIT ONLY - Marketing Discount', 2, 51, 0.01, 1, 1),
(46, 'IGT Self Comp', 2, 0, 0.01, 1, 1),
(47, 'AUDIT ONLY - Employee Discount', 2, 53, 0.01, 1, 1),
(48, 'Credit Card Tips', 4, 0, 0.01, 1, 1),
(49, 'Tribal Food Voucher', 2, 0, 0.01, 1, 1),
(50, 'AUDIT ONLY - Tribal Charge', 2, 55, 0.01, 1, 1),
(51, 'Blackjack Comps', 2, 0, 0.01, 1, 1),
(52, 'Coupons', 0, 0, 0.01, 1, 0),
(53, 'Cash In Drawer', 4, 0, 0.01, 1, 1),
(54, 'AUDIT ONLY - Tribal Tax', 4, 44, 0.01, 1, 1),
(55, 'AUDIT ONLY - State Tax', 4, 45, 0.01, 1, 1),
(56, '0.50', 3, 0, 0.01, 1, 1),
(57, 'Credit Cash Advance', 2, 27, 0.01, 1, 1),
(58, 'Debit Cash Advance', 2, 28, 0.01, 1, 1),
(59, 'Bundled Hundreds ($100)', 1, 43, 100.00, 1, 1),
(60, 'Bundled Fifties ($50)', 1, 43, 50.00, 1, 1),
(61, 'Bundled Twenties ($20)', 1, 43, 20.00, 1, 1),
(62, 'Bundled Tens ($10)', 1, 43, 10.00, 1, 1),
(63, 'Bundled Fives ($5)', 1, 43, 5.00, 1, 1),
(64, 'Bundled Ones ($1)', 1, 0, 1.00, 1, 1),
(65, 'Strapped Hundreds ($100)', 1, 43, 100.00, 1, 1),
(66, 'Strapped Fifties ($50)', 1, 43, 50.00, 1, 1),
(67, 'Strapped Twenties ($20)', 1, 43, 20.00, 1, 1),
(68, 'Strapped Tens ($10)', 1, 43, 10.00, 1, 1),
(69, 'Strapped Fives ($5)', 1, 43, 5.00, 1, 1),
(70, 'Strapped Ones ($1)', 1, 43, 1.00, 1, 1),
(71, 'Boxed Quarters ($0.25)', 1, 43, 500.00, 1, 1),
(72, 'Boxed Dimes ($0.10)', 1, 43, 250.00, 1, 1),
(73, 'Boxed Nickels ($0.05)', 1, 43, 100.00, 1, 1),
(74, 'Boxed Pennies ($0.01)', 1, 43, 25.00, 1, 1),
(75, 'Rolled Quarters ($0.25)', 1, 43, 10.00, 1, 1),
(76, 'Rolled Dimes ($0.10)', 1, 43, 5.00, 1, 1),
(77, 'Rolled Nickels ($0.05)', 1, 43, 2.00, 1, 1),
(78, 'Rolled Pennies ($0.01)', 1, 43, 0.50, 1, 1),
(79, 'Bar Banks on Hold', 1, 0, 0.01, 1, 1),
(80, 'Cashier Banks on Hold', 1, 0, 0.01, 1, 1),
(81, 'ATM on Hold', 1, 0, 0.01, 1, 1),
(82, 'NRT on Hold', 1, 0, 0.01, 1, 1),
(83, '1000.00', 3, 0, 999.99, 1, 1),
(84, 'Mutilated Chips', 3, 0, 0.25, 1, 1),
(85, 'Racked 500.00', 3, 0, 999.99, 1, 1),
(86, 'Racked 1000.00', 3, 0, 999.99, 1, 1),
(87, 'Racked 100.00', 3, 0, 999.99, 1, 1),
(88, 'Racked 25.00', 3, 0, 250.00, 1, 1),
(89, 'Racked 5.00', 3, 0, 500.00, 1, 1),
(90, 'Racked 1.00', 3, 0, 100.00, 1, 1),
(91, 'Racked 0.50', 3, 0, 50.00, 1, 1),
(92, 'Racked 0.25', 3, 0, 25.00, 1, 1),
(93, 'Kiosk Short Pay', 2, 35, 0.01, 1, 1),
(94, 'NNC Promotion', 2, 0, 5.00, 1, 1),
(95, 'Mastercard', 2, 40, 0.01, 1, 1),
(96, 'AUDIT ONLY - Tobacco Sales', 4, 49, 0.01, 1, 1),
(97, 'Cigars', 4, 0, 0.01, 1, 1),
(98, 'Smokeless Tobacco', 4, 0, 0.01, 1, 1),
(99, 'Money Exchange', 1, 4, 0.01, 1, 1),
(100, '1042 Taxes Withheld', 4, 18, 0.01, 1, 1),
(101, 'W2G Taxes Withheld', 4, 32, 0.01, 1, 1),
(102, 'Rolled Ones ($1.00)', 1, 43, 25.00, 1, 1),
(103, 'Bundled Hundreds ($100.00)', 1, 0, 100.00, 0, 1),
(104, 'Bundled Twenties ($20.00)', 1, 0, 20.00, 0, 1),
(105, 'Bundled Tens ($10.00)', 1, 0, 10.00, 0, 1),
(106, 'Bundled Fives ($5.00)', 1, 0, 5.00, 0, 1),
(107, 'Bundled Ones ($1.00)', 1, 0, 1.00, 0, 1),
(108, 'Strapped Hundreds ($100.00)', 1, 0, 999.99, 0, 1),
(109, 'Strapped Fifties ($50.00)', 1, 0, 999.99, 0, 1),
(110, 'Strapped Twenties ($20.00)', 1, 43, 20.00, 0, 1),
(111, 'Strapped Tens ($10.00)', 1, 0, 999.99, 0, 1),
(112, 'Strapped Fives ($5.00)', 1, 0, 500.00, 0, 1),
(113, 'Strapped Ones ($1.00)', 1, 0, 100.00, 0, 1),
(114, 'ATM Short Pay', 2, 35, 0.01, 1, 1),
(115, 'Total Payment', 4, 23, 0.01, 1, 1),
(116, 'Jackpot Check Received', 5, 0, 0.01, 1, 1),
(117, 'ATM/Kiosk Short Pay', 2, 35, 0.01, 1, 1),
(118, 'AUDIT ONLY - F&B Sales', 4, 46, 0.01, 1, 1),
(119, 'AUDIT ONLY - Uniform Personnel Discount', 2, 51, 0.01, 1, 1),
(120, 'AUDIT ONLY - Open $ Discount', 2, 52, 0.01, 1, 1),
(121, 'AUDIT ONLY - Employee Charge', 2, 56, 0.01, 1, 1),
(122, 'AUDIT ONLY - Comps', 2, 57, 0.01, 1, 1),
(123, 'AUDIT ONLY - Credit Card Tips', 4, 17, 0.01, 1, 1),
(124, 'AUDIT ONLY - Misc Items', 4, 50, 0.01, 1, 1),
(125, 'Dollar ($1.00)', 1, 0, 1.00, 1, 1),
(126, 'Jackpot Check Issued', 5, 0, 0.01, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `export`
--

CREATE TABLE `export` (
  `export_id` int(11) NOT NULL,
  `game_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `file_type`
--

CREATE TABLE `file_type` (
  `file_type_id` int(11) NOT NULL,
  `file_extension` varchar(100) NOT NULL,
  `file_description` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file_type`
--

INSERT INTO `file_type` (`file_type_id`, `file_extension`, `file_description`, `status`) VALUES
(1, 'jpg', 'jpg', 1),
(2, 'jpeg', 'jpeg', 1),
(3, 'png', 'png', 1),
(4, 'gif', 'gif', 1),
(5, 'pdf', 'pdf', 1),
(6, 'doc', 'doc', 1),
(7, 'docx', 'docx', 1),
(8, 'xls', 'xls', 1),
(9, 'xlsx', 'xlsx', 1),
(10, 'odt', 'odt', 1),
(11, 'csv', 'csv', 1),
(12, 'txt', 'txt', 1),
(13, 'rtf', 'rtf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `form_id` int(11) NOT NULL,
  `form_description` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`form_id`, `form_description`, `status`) VALUES
(1, 'Count In', 1),
(2, 'Count Out Cage', 1),
(3, 'Decrease Form', 1),
(4, 'Increase Form', 1),
(5, 'Soft Count Drop Sheet Summary', 1),
(6, 'Begin/End Count Form', 1),
(7, 'ATM/Kiosk Return', 1),
(8, 'ATM/Kiosk Fill', 1),
(9, 'Deposit Form', 1),
(10, 'Count Out Bar', 1),
(11, 'Commission Drop', 1),
(12, 'Players Pool Drop', 1),
(13, 'Money Found', 1),
(14, 'Miscellaneous Receipt', 1),
(15, 'Miscellaneous Disbursement', 1),
(16, 'Table Games Drop', 1),
(17, 'Test Money', 1),
(18, 'Vending Machine Tobacco', 1),
(19, 'Vending Machine', 1),
(20, 'BlackJack Fills and Credits', 1);

-- --------------------------------------------------------

--
-- Table structure for table `form_item`
--

CREATE TABLE `form_item` (
  `form_id` int(11) NOT NULL,
  `data_item_id` int(11) NOT NULL,
  `item_order` int(11) NOT NULL,
  `form_section` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_item`
--

INSERT INTO `form_item` (`form_id`, `data_item_id`, `item_order`, `form_section`) VALUES
(16, 7, 0, 0),
(16, 6, 1, 0),
(16, 5, 2, 0),
(16, 4, 3, 0),
(16, 3, 4, 0),
(16, 1, 5, 0),
(16, 2, 6, 0),
(16, 83, 8, 1),
(16, 15, 9, 1),
(16, 16, 10, 1),
(16, 17, 11, 1),
(16, 18, 12, 1),
(16, 19, 13, 1),
(16, 56, 14, 1),
(16, 20, 15, 1),
(16, 29, 16, 1),
(8, 7, 0, 0),
(8, 6, 1, 0),
(8, 5, 2, 0),
(8, 4, 3, 0),
(8, 3, 4, 0),
(8, 1, 5, 0),
(8, 2, 6, 0),
(8, 8, 8, 1),
(8, 9, 9, 1),
(8, 10, 10, 1),
(8, 11, 11, 1),
(8, 12, 12, 1),
(8, 13, 13, 1),
(9, 7, 0, 0),
(9, 6, 1, 0),
(9, 5, 2, 0),
(9, 4, 3, 0),
(9, 3, 4, 0),
(9, 1, 5, 0),
(9, 2, 6, 0),
(9, 14, 8, 1),
(9, 8, 9, 1),
(9, 9, 10, 1),
(9, 10, 11, 1),
(9, 11, 12, 1),
(9, 12, 13, 1),
(9, 13, 14, 1),
(9, 33, 16, 2),
(9, 34, 17, 2),
(9, 28, 18, 2),
(9, 35, 19, 2),
(17, 7, 0, 0),
(17, 6, 1, 0),
(17, 5, 2, 0),
(17, 4, 3, 0),
(17, 3, 4, 0),
(17, 1, 5, 0),
(17, 2, 6, 0),
(17, 8, 8, 1),
(17, 9, 9, 1),
(17, 10, 10, 1),
(17, 11, 11, 1),
(17, 12, 12, 1),
(17, 13, 13, 1),
(19, 7, 0, 0),
(19, 6, 1, 0),
(19, 5, 2, 0),
(19, 4, 3, 0),
(19, 3, 4, 0),
(19, 1, 5, 0),
(19, 2, 6, 0),
(19, 8, 8, 1),
(19, 9, 9, 1),
(19, 10, 10, 1),
(19, 11, 11, 1),
(19, 12, 12, 1),
(19, 13, 13, 1),
(20, 83, 0, 0),
(20, 15, 1, 0),
(20, 16, 2, 0),
(20, 17, 3, 0),
(20, 18, 4, 0),
(20, 19, 5, 0),
(20, 20, 6, 0),
(1, 7, 0, 0),
(1, 6, 1, 0),
(1, 5, 2, 0),
(1, 4, 3, 0),
(1, 3, 4, 0),
(1, 1, 5, 0),
(1, 2, 6, 0),
(1, 8, 8, 1),
(1, 9, 9, 1),
(1, 10, 10, 1),
(1, 11, 11, 1),
(1, 12, 12, 1),
(1, 13, 13, 1),
(1, 14, 14, 1),
(5, 1, 0, 0),
(5, 3, 1, 0),
(5, 4, 2, 0),
(5, 5, 3, 0),
(5, 6, 4, 0),
(5, 7, 5, 0),
(5, 2, 6, 0),
(15, 7, 0, 0),
(15, 6, 1, 0),
(15, 5, 2, 0),
(15, 4, 3, 0),
(15, 3, 4, 0),
(15, 1, 5, 0),
(15, 2, 6, 0),
(15, 32, 7, 0),
(15, 8, 9, 1),
(15, 9, 10, 1),
(15, 10, 11, 1),
(15, 11, 12, 1),
(15, 12, 13, 1),
(15, 13, 14, 1),
(13, 7, 0, 0),
(13, 6, 1, 0),
(13, 5, 2, 0),
(13, 4, 3, 0),
(13, 3, 4, 0),
(13, 1, 5, 0),
(13, 2, 6, 0),
(13, 8, 8, 1),
(13, 9, 9, 1),
(13, 10, 10, 1),
(13, 11, 11, 1),
(13, 12, 12, 1),
(13, 13, 13, 1),
(3, 35, 0, 0),
(3, 23, 1, 0),
(3, 24, 2, 0),
(3, 22, 3, 0),
(3, 21, 4, 0),
(3, 27, 5, 0),
(3, 31, 6, 0),
(3, 25, 7, 0),
(3, 101, 8, 0),
(3, 100, 9, 0),
(3, 93, 10, 0),
(3, 7, 12, 1),
(3, 6, 13, 1),
(3, 5, 14, 1),
(3, 4, 15, 1),
(3, 3, 16, 1),
(3, 1, 17, 1),
(3, 2, 18, 1),
(3, 28, 19, 1),
(3, 8, 20, 1),
(3, 9, 21, 1),
(3, 10, 22, 1),
(3, 11, 23, 1),
(3, 12, 24, 1),
(3, 13, 25, 1),
(6, 38, 0, 0),
(6, 28, 1, 0),
(6, 40, 2, 0),
(6, 35, 3, 0),
(6, 99, 4, 0),
(6, 59, 6, 1),
(6, 60, 7, 1),
(6, 61, 8, 1),
(6, 62, 9, 1),
(6, 63, 10, 1),
(6, 64, 11, 1),
(6, 65, 12, 1),
(6, 66, 13, 1),
(6, 67, 14, 1),
(6, 68, 15, 1),
(6, 69, 16, 1),
(6, 70, 17, 1),
(6, 7, 18, 1),
(6, 6, 19, 1),
(6, 5, 20, 1),
(6, 4, 21, 1),
(6, 3, 22, 1),
(6, 2, 23, 1),
(6, 1, 24, 1),
(6, 71, 26, 2),
(6, 72, 27, 2),
(6, 73, 28, 2),
(6, 74, 29, 2),
(6, 102, 30, 2),
(6, 75, 31, 2),
(6, 76, 32, 2),
(6, 77, 33, 2),
(6, 78, 34, 2),
(6, 8, 35, 2),
(6, 9, 36, 2),
(6, 10, 37, 2),
(6, 11, 38, 2),
(6, 12, 39, 2),
(6, 13, 40, 2),
(14, 7, 0, 0),
(14, 6, 1, 0),
(14, 5, 2, 0),
(14, 4, 3, 0),
(14, 3, 4, 0),
(14, 1, 5, 0),
(14, 2, 6, 0),
(14, 32, 7, 0),
(14, 8, 9, 1),
(14, 9, 10, 1),
(14, 10, 11, 1),
(14, 11, 12, 1),
(14, 12, 13, 1),
(14, 13, 14, 1),
(14, 116, 16, 2),
(4, 7, 0, 0),
(4, 6, 1, 0),
(4, 5, 2, 0),
(4, 4, 3, 0),
(4, 3, 4, 0),
(4, 1, 5, 0),
(4, 2, 6, 0),
(4, 8, 8, 1),
(4, 9, 9, 1),
(4, 10, 10, 1),
(4, 11, 11, 1),
(4, 12, 12, 1),
(4, 13, 13, 1),
(4, 14, 14, 1),
(4, 116, 16, 2),
(2, 35, 0, 0),
(2, 23, 1, 0),
(2, 24, 2, 0),
(2, 22, 3, 0),
(2, 21, 4, 0),
(2, 27, 5, 0),
(2, 31, 6, 0),
(2, 25, 7, 0),
(2, 101, 8, 0),
(2, 100, 9, 0),
(2, 117, 10, 0),
(2, 7, 12, 1),
(2, 6, 13, 1),
(2, 5, 14, 1),
(2, 4, 15, 1),
(2, 3, 16, 1),
(2, 1, 17, 1),
(2, 2, 18, 1),
(2, 8, 19, 1),
(2, 9, 20, 1),
(2, 10, 21, 1),
(2, 11, 22, 1),
(2, 12, 23, 1),
(2, 13, 24, 1),
(10, 42, 0, 0),
(10, 95, 1, 0),
(10, 43, 2, 0),
(10, 44, 3, 0),
(10, 115, 4, 0),
(10, 7, 6, 1),
(10, 6, 7, 1),
(10, 5, 8, 1),
(10, 4, 9, 1),
(10, 3, 10, 1),
(10, 1, 11, 1),
(10, 2, 12, 1),
(10, 8, 13, 1),
(10, 9, 14, 1),
(10, 10, 15, 1),
(10, 11, 16, 1),
(10, 12, 17, 1),
(10, 13, 18, 1),
(10, 54, 20, 2),
(10, 118, 21, 2),
(10, 96, 22, 2),
(10, 124, 23, 2),
(10, 45, 24, 2),
(10, 119, 25, 2),
(10, 47, 26, 2),
(10, 120, 27, 2),
(10, 50, 28, 2),
(10, 121, 29, 2),
(10, 122, 30, 2),
(10, 123, 31, 2),
(7, 7, 0, 0),
(7, 6, 1, 0),
(7, 5, 2, 0),
(7, 4, 3, 0),
(7, 3, 4, 0),
(7, 1, 5, 0),
(7, 2, 6, 0),
(7, 24, 8, 1),
(7, 13, 10, 2),
(7, 12, 11, 2),
(7, 10, 12, 2),
(11, 15, 0, 0),
(11, 16, 1, 0),
(11, 17, 2, 0),
(11, 18, 3, 0),
(11, 19, 4, 0),
(11, 56, 5, 0),
(11, 20, 6, 0),
(11, 29, 7, 0),
(12, 7, 0, 0),
(12, 6, 1, 0),
(12, 5, 2, 0),
(12, 4, 3, 0),
(12, 3, 4, 0),
(12, 1, 5, 0),
(12, 2, 6, 0),
(12, 8, 8, 1),
(12, 9, 9, 1),
(12, 10, 10, 1),
(12, 11, 11, 1),
(12, 12, 12, 1),
(12, 13, 13, 1),
(18, 7, 0, 0),
(18, 6, 1, 0),
(18, 5, 2, 0),
(18, 4, 3, 0),
(18, 3, 4, 0),
(18, 1, 5, 0),
(18, 2, 6, 0),
(18, 8, 8, 1),
(18, 9, 9, 1),
(18, 10, 10, 1),
(18, 11, 11, 1),
(18, 12, 12, 1),
(18, 13, 13, 1);

-- --------------------------------------------------------

--
-- Table structure for table `item_category`
--

CREATE TABLE `item_category` (
  `item_category_id` int(11) NOT NULL,
  `item_category_name` varchar(100) NOT NULL,
  `impress_count` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_category`
--

INSERT INTO `item_category` (`item_category_id`, `item_category_name`, `impress_count`) VALUES
(1, 'Cash', 1),
(2, 'Non-Cash', 0),
(3, 'Chips', 0),
(4, 'Sales', 0),
(5, 'Cash Equivalent', 1);

-- --------------------------------------------------------

--
-- Table structure for table `login_log`
--

CREATE TABLE `login_log` (
  `login_log_id` int(11) NOT NULL,
  `username` varchar(500) NOT NULL,
  `fail_reason` varchar(500) NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_log`
--

INSERT INTO `login_log` (`login_log_id`, `username`, `fail_reason`, `log_date`) VALUES
(1, 'VaultAdmin', 'successful', '2020-08-31 14:39:39'),
(2, 'SupportAdmin', 'successful', '2020-08-31 14:39:48');

-- --------------------------------------------------------

--
-- Table structure for table `message_code`
--

CREATE TABLE `message_code` (
  `message_id` int(11) NOT NULL,
  `message_type` varchar(50) NOT NULL,
  `message_key` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_code`
--

INSERT INTO `message_code` (`message_id`, `message_type`, `message_key`, `message`) VALUES
(1, 'success', 'ACCOUNT_SUCCESSFULLY_ADDED', 'Account successfully added.'),
(2, 'success', 'ACCOUNT_SUCCESSFULLY_MODIFIED', 'Account successfully updated.'),
(3, 'warning', 'AD_ACCOUNT_LOCKED', 'Cannot log in because your account has been locked by failed log in attempts. Contact System Administrator.'),
(4, 'danger', 'AD_BASEDN_NOT_CONFIGURED', 'Active Directory BaseDN has not been configured.'),
(5, 'danger', 'AD_CONNECTION_FAIL', 'Unable to connect to Active Directory.'),
(6, 'warning', 'AD_DISABLED_USER', 'Cannot log in because your account in Active Directory is disabled. Contact System Administrator.'),
(7, 'danger', 'AD_HOSTS_NOT_CONFIGURED', 'Active Directory domain controller has not been configured.'),
(8, 'danger', 'AD_INVALID_CREDENTIALS', 'Cannot login because the credentials you provided do not match those in the system or your password has expired.  Try logging in again with the proper credentials.'),
(9, 'warning', 'AD_PASSWORD_EXPIRED', 'Cannot log in because your password has expired. Contact System Administrator.'),
(10, 'danger', 'AD_PASSWORD_NOT_CONFIGURED', 'Active Directory password has not been configured.'),
(11, 'danger', 'AD_PORTS_NOT_CONFIGURED', 'Active Directory ports has not been configured.'),
(12, 'warning', 'AD_SID_NOT_FOUND', 'Active Directory SID not found.'),
(13, 'info', 'AD_USER_FOUND', 'Was found in Active Directory.'),
(14, 'warning', 'AD_USER_NOT_FOUND', 'Username not found.'),
(15, 'danger', 'AD_USERNAME_NOT_CONFIGURED', 'Active Directory username has not been configured.'),
(16, 'label', 'ADD_TO_CAGESENTRY', 'Would you like to add this user to Virtual Vault?'),
(17, 'success', 'ADDITIONAL_MAIN_BANKERS_ADDED', 'Main Banker added.'),
(18, 'info', 'ADMIN_LOG_ADDED', '%s has been added'),
(19, 'info', 'ADMIN_LOG_ADDED_DETAIL', '%s set to %s'),
(20, 'info', 'ADMIN_LOG_ITEM_CHANGE', '%s has been %s'),
(21, 'info', 'ADMIN_LOG_UPDATED', '%s has been updated'),
(22, 'info', 'ADMIN_LOG_UPDATED_DETAIL', '%s updated from %s to %s'),
(23, 'warning', 'ALREADY_AUTHENTICATED', 'UNEXPECTED ERROR #02'),
(24, 'warning', 'BANK_ALREADY_REQUESTED', 'You have already performed this activity.'),
(25, 'success', 'BANK_DEFAULT_VALUES_ADDED', 'Bank Default Values sucessfully added.'),
(26, 'success', 'BANK_DEFAULT_VALUES_SUCCESSFULLY_MODIFIED', 'Bank Default Details Values updated.'),
(27, 'warning', 'BANK_DEFAULT_VALUES_UPDATE_UNSUCCESSFULLY', 'Bank Default Details Update Failed.'),
(28, 'success', 'BANK_INSTANCE_ADDED', 'Bank instance was added.'),
(29, 'success', 'BANK_INSTANCE_DETAIL_ADDED', 'UNEXPECTED ERROR #04'),
(30, 'success', 'BANK_INSTANCE_DETAILS_ADDED', 'UNEXPECTED ERROR #05'),
(31, 'danger', 'BANK_INSTANCE_DETAILS_INSERT_FAILED', 'UNEXPECTED ERROR #06'),
(32, 'success', 'BANK_INSTANCE_UPDATED', 'UNEXPECTED ERROR #07'),
(33, 'label', 'BANK_PENDING_CANCEL_LABEL', 'Your bank request is currently pending.  Would you like to cancel it?'),
(34, 'info', 'BANK_PENDING_CANCEL_NO', 'Your request is still pending.'),
(35, 'success', 'BANK_PENDING_CANCEL_YES', 'Your request has been cancelled.'),
(36, 'label', 'BANK_PENDING_REJECT_LABEL', 'Your bank was rejected.  Would you like to request another bank?'),
(37, 'danger', 'BANK_REJECTED', 'The bank was rejected.  There is a variance between what was submitted and what was verified by the Vault.  Recount all inventory and resubmit bank for verification.'),
(38, 'success', 'BANK_REQUEST_ADDED', 'Your request has been sent.'),
(39, 'label', 'BANK_REQUEST_ANOTHER_LABEL', 'Would you like to request another bank?'),
(40, 'info', 'BANK_REQUEST_ANOTHER_NO', 'UNEXPECTED ERROR #08'),
(41, 'success', 'BANK_REQUEST_FULLFILLED', 'The request has been filled.'),
(42, 'success', 'BANK_REQUEST_INSTANCE_ADDED', 'Bank request instance was added.'),
(43, 'danger', 'BANK_REQUEST_REJECTED', 'The request has been rejected.'),
(44, 'success', 'BANK_REQUEST_UPDATED', 'UNEXPECTED ERROR #09'),
(45, 'warning', 'BANK_REQUEST_UPDATED_FAILED_ALREADY_COMPLETED', 'UNEXPECTED ERROR #10'),
(46, 'success', 'BANK_STATUS_CLOSED', 'UNEXPECTED ERROR #11'),
(47, 'success', 'BANK_STATUS_FILLED', 'UNEXPECTED ERROR #12'),
(48, 'success', 'BANK_STATUS_OPENED', 'UNEXPECTED ERROR #13'),
(49, 'success', 'BANK_STATUS_REJECTED', 'UNEXPECTED ERROR #14'),
(50, 'success', 'BANK_STATUS_REQUESTED', 'UNEXPECTED ERROR #15'),
(51, 'success', 'BANK_STATUS_TRANSFERED', 'Your bank has been transferred.'),
(52, 'success', 'BANK_SUCCESSFULLY_MODIFIED', 'Bank successfully updated.'),
(53, 'warning', 'BANK_USER_NOT_ASSOCIATED', 'UNEXPECTED ERROR #16'),
(54, 'warning', 'BANK_VARIANCE', 'You have a variance.'),
(55, 'warning', 'BANK_VARIANCE_EXCEEDED', 'You have a variance that is over the allowable threshold.'),
(56, 'warning', 'BANK_VARIANCE_PENDING', 'The bank is being returned with a variance.  If you accept this variance, select "Continue" to return bank with variance.  Select "Cancel" to return to the Count Out screen.'),
(57, 'label', 'BANK_VARIANCE_RANGE_ERROR', 'The %s field only allows positive numbers and a period.'),
(58, 'success', 'BANK_VERIFIED', 'The item was verified.'),
(59, 'success', 'CAGESENTRY_BANK_ADDED', 'Bank successfully added.'),
(60, 'success', 'CAGESENTRY_USER_ADDED', 'User successfully added to Virtual Vault.'),
(61, 'info', 'CAGESENTRY_USER_EXISTS', 'Already exists in Virtual Vault.'),
(62, 'danger', 'DATA_ITEM_BEEN_USED', 'Data Item name and increment cannot be changed since the data item has been used.'),
(63, 'danger', 'DATA_ITEM_STATUS_LOCKED', 'Data Item cannot be disabled since it is in use.'),
(64, 'success', 'DATA_ITEM_SUCCESSFULLY_ADDED', 'Item successfully added.'),
(65, 'success', 'DATA_ITEM_SUCCESSFULLY_MODIFIED', 'Item successfully updated.'),
(66, 'danger', 'DB_SETUP_AD_INFORMATION', 'Missing database setup information.'),
(67, 'warning', 'DISABLED_USER', 'Cannot log in because your Virtual Vault account is disabled. Contact System Administrator.'),
(68, 'danger', 'FORM_STATUS_LOCKED', 'Form cannot be disabled since it is in use.'),
(69, 'success', 'FORM_SUCCESSFULLY_ADDED', 'Form successfully added.'),
(70, 'success', 'FORM_SUCCESSFULLY_MODIFIED', 'Form successfully updated.'),
(71, 'success', 'MAIN_BANK_OPENED', 'The main bank was opened.'),
(72, 'success', 'MAIN_BANK_TRANSFERED', 'The main bank has been transferred.'),
(73, 'danger', 'MAIN_BANK_USER_ALREADY_ADDED', 'UNEXPECTED ERROR #17'),
(74, 'label', 'MODAL_ACCEPT_VARIANCE', 'UNEXPECTED ERROR #18'),
(75, 'label', 'MODAL_ADDITIONAL_BANKERS', 'Will there be additional Main Bankers?'),
(76, 'label', 'MODAL_CANCEL_PENDING', 'Are you certain you want to cancel this?'),
(77, 'label', 'MODAL_CANCEL_VERIFY', 'UNEXPECTED ERROR #19'),
(78, 'label', 'MODAL_CHANGE_PERMISSION', 'Changing the permission type will erase all current permissions. Are you sure you wish to continue?'),
(79, 'label', 'MODAL_SUBMIT_VARIANCE', 'Would you like to accept this variance?'),
(80, 'label', 'MODAL_VARIANCE_OVERRIDE_REQUIRED', 'Would you like to accept this variance with a supervisor override?'),
(81, 'danger', 'NO_MAIN_BANK_PERMISSION', 'UNEXPECTED ERROR #20'),
(82, 'warning', 'NO_OVERRIDE_PERMISSION', 'You do not have permission to override.'),
(83, 'warning', 'NO_OVERRIDE_YOURSELF', 'You cannot override your own transaction.'),
(84, 'danger', 'NOT_CAGE_SENTRY_USER', 'Cannot log in because you do not have a Virtual Vault account. Contact System Administrator.'),
(85, 'label', 'OPEN_MAIN_BANK_QUESTION', 'Main bank needs to be opened.  Will you be working as a Main Banker?'),
(86, 'warning', 'OUTSTANDING_ACTIVITY', 'You have activities that are still pending.  Please check Bank Activity to ensure all increases and decreases are complete or filled.'),
(87, 'label', 'PENDING_MAIN_BANK_QUESTION', 'Are you verifying the Main Bank?'),
(88, 'label', 'PREVIOUSLY_ADDED_TO_CAGESENTRY', 'Has previously been added to Virtual Vault.  Would you like to view this user?'),
(89, 'label', 'QUERY_NO_RECORDS', 'Query returned 0 records.'),
(90, 'warning', 'REQUESTED_EMPTY_BANK', 'You did not enter any amounts.'),
(91, 'info', 'SESSION_EXPIRED', 'You have been logged out due to inactivity.'),
(92, 'success', 'SYSTEM_SETTING_SUCCESSFULLY_MODIFIED', 'System settings successfully modified.'),
(93, 'success', 'TRANSACTION_ADDED', 'Transaction created.'),
(94, 'danger', 'TRANSACTION_BEEN_USED', 'Transaction name cannot be changed since the transaction has been used.'),
(95, 'danger', 'TRANSACTION_NO_DATA', 'No data entered for transaction.'),
(96, 'success', 'TRANSACTION_REJECTED', 'Transaction rejected.'),
(97, 'success', 'TRANSACTION_RELEASED', 'Released %s item(s) on hold.'),
(98, 'danger', 'TRANSACTION_STATUS_LOCKED', 'Transaction cannot be disabled since it is in use.'),
(99, 'success', 'TRANSACTION_SUCCESSFULLY_ADDED', 'Transaction successfully added.'),
(100, 'success', 'TRANSACTION_SUCCESSFULLY_MODIFIED', 'Transaction successfully updated.'),
(101, 'label', 'TRANSFER_MAIN_BANK_QUESTION', 'Would you like to verify the main bank?'),
(102, 'label', 'USER_ADMIN', 'Will the user be performing administrative or audit functions?'),
(103, 'info', 'USER_LOGOUT', 'You have been logged out. Thanks for visiting.'),
(104, 'success', 'USER_SUCCESSFULLY_MODIFIED', 'User successfully updated.'),
(105, 'label', 'VERIFICATION_COMPLETE_LABEL', 'Would you like to do something else?'),
(106, 'warning', 'VERIFY_EMPTY_BANK', 'UNEXPECTED ERROR #21'),
(107, 'success', 'BACKUP_RESTORED', 'Database backup has been restored.'),
(108, 'warning', 'CURRENT_PASSWORD_INCORRECT', 'Current admin password incorrect.'),
(109, 'warning', 'NEW_PASSWORDS_DO_NOT_MATCH', 'New passwords do not match'),
(110, 'warning', 'PASSWORD_NOT_COMPLEX', 'Password must be stronger. %s'),
(111, 'success', 'LOCAL_PASSWORD_UPDATED', 'Password Updated.'),
(112, 'success', 'TIP_TRANSACTION_ADDED', 'Tips added.'),
(113, 'warning', 'BANK_UNABLE_TO_VERIFY', 'The request status has changed.'),
(114, 'info', 'attestation', 'By logging into Virtual Vault, I understand that my credentials represent my digital signature and my attestation to the accuracy of activities I perform in Virtual Vault. I understand that sharing my credentials is against company policy and that I am responsible for any activities that occur as a result of credential sharing. By clicking "Log In" below, I acknowledge that my credentials will serve as a permanent record of these understandings.'),
(115, 'info', 'export_date_label', 'Game Date'),
(116, 'warning', 'BANK_TRANSFER_IN_PROGRESS', 'A bank transfer is already in progress.'),
(117, 'warning', 'USER_PENDING_ACTION', 'A bank transfer is already in progress.'),
(118, 'success', 'ADDITIONAL_MAIN_BANKERS_REMOVED', 'Main Banker removed.'),
(119, 'warning', 'PASSWORD_COMPLEX', 'Password must be at least 8 characters in length and include at least 3 of the following. Uppercase letter, lowercase letter, number or symbol.'),
(120, 'danger', 'PASSWORD_HISTORY', 'Password has been used too recently.'),
(121, 'success', 'USER_DEPOSIT_ADDED', 'Deposit Submitted.'),
(122, 'danger', 'USER_DEPOSIT_INVALID_DATE', 'Invalid Bank Date.'),
(123, 'success', 'CANCEL_FILL', 'Request canceled.'),
(124, 'danger', 'CANCEL_FILL_FAIL', 'There was an error canceling the request'),
(125, 'success', 'T31_CUSTOMER_TRANSACTION_ADDED', 'Transaction recorded.'),
(126, 'danger', 'T31_CUSTOMER_SSN_USED', '%s in use by %s'),
(127, 'danger', 'T31_CUSTOMER_PLAYER_CLUB_USED', '%s in use by %s'),
(128, 'danger', 'T31_CUSTOMER_ID_NUMBER_USED', '%s in use by %s'),
(129, 'success', 'T31_CUSTOMER_MERGE', 'Customer Merged'),
(130, 'success', 'T31_TRANSACTION_ENTRY_SAVED', 'Entry Updated'),
(131, 'danger', 'MAINTENANCE_MODE_ON', 'Maintenance mode is currently enabled. User logins disabled.'),
(132, 'danger', 'PASSWORD_EXPIRED', 'Your password expired, please contact your administrator.'),
(133, 'warning', 'PASSWORD_IS_ABOUT_TO_EXPIRE', 'Your password will expire soon, please update it.'),
(134, 'danger', 'PASSWORD_UPDATED', 'Password has been updated.'),
(135, 'success', 'BANK_CAT_SUCCESSFULLY_ADDED', 'Bank Category Added.'),
(136, 'success', 'BANK_CAT_SUCCESSFULLY_MODIFIED', 'Bank Category Updated.');

-- --------------------------------------------------------

--
-- Table structure for table `meta_data`
--

CREATE TABLE `meta_data` (
  `meta_id` int(11) NOT NULL,
  `label` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meta_data`
--

INSERT INTO `meta_data` (`meta_id`, `label`) VALUES
(1, 'Do not reopen');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `version` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`id`, `created_at`, `version`, `name`) VALUES
(1, '2019-10-02 00:09:24', 0, '0000000000_virtualvault_initial_database_structure'),
(2, '2019-10-02 00:09:24', 1, '0000000001_add_default_users'),
(3, '2019-10-02 00:09:24', 2, '0000000002_add_default_transactions'),
(4, '2019-10-02 00:09:24', 3, '0000000003_add_default_admin_log_category'),
(5, '2019-10-02 00:09:24', 4, '0000000004_add_default_bank'),
(6, '2019-10-02 00:09:24', 5, '0000000005_add_default_bank_category'),
(7, '2019-10-02 00:09:24', 6, '0000000006_add_default_item_category'),
(8, '2019-10-02 00:09:25', 7, '0000000007_add_default_message_code'),
(9, '2019-10-02 00:09:25', 8, '0000000008_add_default_system_settings'),
(10, '2019-10-02 00:09:25', 9, '0000000009_set_autoincrement_user_table'),
(11, '2019-10-02 00:09:25', 100, '0000000100_VV-244_attestation'),
(12, '2019-10-02 00:09:25', 101, '0000000101_VV-249_add_encrypted_ad_password_to_settings'),
(13, '2019-10-02 00:09:25', 102, '0000000102_VV-276_export_routine_label_default'),
(14, '2019-10-02 00:09:25', 103, '0000000103_VV-265_add_automate_new_day_field_and_activate'),
(15, '2019-10-02 00:09:25', 104, '0000000104_VV-267_add_allowed_file_types'),
(16, '2019-10-02 00:09:26', 1518389811, '1518389811_add_hash_and_type_to_user'),
(17, '2019-10-02 00:09:26', 1527122252, '1527122252_add_name_login_to_user'),
(18, '2019-10-02 00:09:26', 1527166524, '1527166524_add_unique_sid_index_to_user'),
(19, '2019-10-02 00:09:26', 1528402167, '1528402167_VV-252_bank_default_detail_primary_key'),
(20, '2019-10-02 00:09:26', 1530001234, '1530001234_VV-247_transfer_more_than_once'),
(21, '2019-10-02 00:09:26', 1530002345, '1530002345_VV-288_stop_reissuing_banks'),
(22, '2019-10-02 00:09:26', 1530003456, '1530003456_structure_changes'),
(23, '2019-10-02 00:09:26', 1531174428, '1531174428_add_active_to_bank_users'),
(24, '2019-10-02 00:09:27', 1531460025, '1531460025_add_created_at_to_bank_user'),
(25, '2019-10-02 00:09:27', 1531462440, '1531462440_set_message_code_additional_main_bankers_added'),
(26, '2019-10-02 00:09:27', 1531462592, '1531462592_set_message_code_additional_main_bankers_removed'),
(27, '2019-10-02 00:09:27', 1533246037, '1533246037_VV-223_report_permissions'),
(28, '2019-10-02 00:09:27', 1533673309, '1533673309_VV_290_add_password_complexity_for_local_users'),
(29, '2019-10-02 00:09:27', 1533673415, '1533673415_VV_292_password_history_list'),
(30, '2019-10-02 00:09:27', 1533673564, '1533673564_VV_292_password_history_list_triggers_run_manually'),
(31, '2019-10-02 00:09:27', 1534274376, '1534274376_VV-266_allow_configurable_file_types'),
(32, '2019-10-02 00:09:27', 1534446634, '1534446634_VV-280_transaction_report'),
(33, '2019-10-02 00:09:27', 1535245838, '1535245838_VV-317_detail_activity_report'),
(34, '2019-10-02 00:09:27', 1535246972, '1535246972_VV-319_expected_deposit_report'),
(35, '2019-10-02 00:09:27', 1535553447, '1535553447_VV-318_exclude_banks'),
(36, '2019-10-02 00:09:27', 1536266430, '1536266430_VV-316_auto_close_level_3_banks.sql'),
(37, '2019-10-02 00:09:27', 1543357919, '1543357919_VV-343_timestamp_change'),
(38, '2019-10-02 00:09:27', 1543458939, '1543458939_VV-482_user_deposit'),
(39, '2019-10-02 00:09:27', 1553253957, '1553253957_VV-530_activity_report_changes'),
(40, '2020-08-31 14:33:46', 1537412087, '1537412087_VV-222_add_cancel_fill_messages'),
(41, '2020-08-31 14:33:46', 1540410506, '1540410506_VV-325_convert_system_settings_to_key_value'),
(42, '2020-08-31 14:33:46', 1550458291, '1550458291_add_t31_mtl_summary_report'),
(43, '2020-08-31 14:33:46', 1560000000, '1560000000_VV-368_breakout_permissions'),
(44, '2020-08-31 14:33:46', 1560000100, '1560000100_VV-319_enable_all_file_types'),
(45, '2020-08-31 14:33:48', 1567518449, '1567518449_VV-511_title31_setup'),
(46, '2020-08-31 14:33:49', 1570187729, '1570187729_VV-525_add_encrypted_to_t31_customer'),
(47, '2020-08-31 14:33:49', 1573061629, '1573061629_add_maintenance_mode_message_codes'),
(48, '2020-08-31 14:33:49', 1573585836, '1573585836_VV-545_cashier_tip_permission'),
(49, '2020-08-31 14:33:49', 1576873996, '1576873996_VV-293_make_password_complexity_configurable'),
(50, '2020-08-31 14:33:49', 1576874235, '1576874235_VV-553_add_password_expiration_for_local_users'),
(51, '2020-08-31 14:33:49', 1578598076, '1578598076_VV-388_add_summary_variance_report'),
(52, '2020-08-31 14:33:49', 1581522090, '1581522090_VV-559_update_login_failed_message'),
(53, '2020-08-31 14:33:49', 1585854285, '1585854285_VV-548_update_variance_report_name'),
(54, '2020-08-31 14:33:49', 1585854352, '1585854352_VV-547_add_cashier_variance_report'),
(55, '2020-08-31 14:33:49', 1585874859, '1585874859_VV-389_add_detail_variance_report'),
(56, '2020-08-31 14:33:49', 1588089757, '1588089757_VV-572_change_reports_to_use_name_instead_of_id'),
(57, '2020-08-31 14:33:49', 1588089762, '1588089762_VV-392_add_open_banks_report'),
(58, '2020-08-31 14:33:49', 1588089763, '1588089763_VV-392_add_bank_instance_log_table'),
(59, '2020-08-31 14:33:49', 1588793003, '1588793003_VV-567_zero_dollar_banks'),
(60, '2020-08-31 14:33:49', 1589834173, '1589834173_VV-270_bank_type_configurable');

-- --------------------------------------------------------

--
-- Table structure for table `password_history`
--

CREATE TABLE `password_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `change_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `permission_id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permission_id`, `name`) VALUES
(1, 'bank_level'),
(2, 'override'),
(3, 'variance'),
(4, 'is_admin'),
(5, 'user_manage'),
(6, 'data_item_manage'),
(7, 'form_manage'),
(8, 'bank_manage'),
(9, 'transaction_manage'),
(10, 'account_manage'),
(11, 'audit_manage'),
(12, 'system_manage'),
(13, 'impress_manage'),
(14, 'report_manage'),
(15, 'status'),
(16, 'Manage Users'),
(17, 'Title 31'),
(18, 'T31 Settings'),
(19, 'T31 Transactions'),
(20, 'Edit Transaction History'),
(21, 'Override Game Date Restrictions'),
(22, 'Merge Customers'),
(23, 'logs'),
(24, 'backups'),
(25, 'usertips'),
(26, 'bank_cat_manage');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(11) NOT NULL,
  `report_name` varchar(100) NOT NULL,
  `report_function` varchar(500) NOT NULL,
  `report_status` int(11) NOT NULL,
  `report_section` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `report_name`, `report_function`, `report_status`, `report_section`) VALUES
(3, 'Variance Inquiry', 'reports/variance_report', 1, 0),
(4, 'Transaction Report', 'reports/transaction_report', 1, 0),
(5, 'Detail Activity Report', 'reports/bank_transfer_by_day_report', 1, 0),
(6, 'Expected Deposit Report', 'reports/expected_deposit_report', 1, 0),
(7, 'User Matrix', 'reports/user_matrix_download', 1, 0),
(8, 'Summary Activity Report', 'reports/bank_transfer_report', 1, 0),
(1000, 'Title 31 Transaction Summary', 't31/reports/mtl_summary', 1, 1),
(1001, 'Customer CTR', 't31/reports/ctr', 1, 1),
(1002, 'Summary Variance Report', 'reports/summary_variance_report', 1, 0),
(1004, 'Cashier Variance Report', 'reports/cashier_variance_report', 1, 0),
(1005, 'Detail Variance Report', 'reports/variance_inquiry_report', 1, 0),
(1006, 'Activity Inquiry', 'reports/activity_inquiry_filter', 1, 0),
(1007, 'Current Open Banks', 'reports/open_history_report/', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `report_user`
--

CREATE TABLE `report_user` (
  `user_id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL,
  `setting_name` varchar(250) NOT NULL,
  `setting_value` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_id`, `setting_name`, `setting_value`) VALUES
(1, 'network_type', '1'),
(2, 'network_ip', '1.1.1.1'),
(3, 'network_subnet', '1.1.1.1'),
(4, 'network_gateway', '129.168.1.1'),
(5, 'session_timeout', '1500'),
(6, 'ad_controllers', 'dc01.yourdomain.com'),
(7, 'ad_username', 'user@yourdomain.com'),
(8, 'ad_password', 'nothing'),
(9, 'ad_password_encrypted', ''),
(10, 'ad_ports', '389'),
(11, 'ad_basedn', 'dc=yourdomain,dc=com'),
(12, 'local_administrator_password', '5f4dcc3b5aa765d61d8327deb882cf99'),
(13, 'default_local_administrator_password', '5f4dcc3b5aa765d61d8327deb882cf99'),
(14, 'support_password', '5f4dcc3b5aa765d61d8327deb882cf99'),
(15, 'impress_amount', '0'),
(16, 'company_name', 'Enter Company Name Here'),
(17, 'mount_path', ''),
(18, 'backup_interval', '15'),
(19, 'automate_end_of_day', '0'),
(20, 'previous_passwords', '0'),
(21, 'minimum_password_length', '0'),
(22, 'password_require_lowercase', '0'),
(23, 'password_require_uppercase', '0'),
(24, 'password_special_character', '0'),
(25, 'password_require_number', '0'),
(26, 'password_expire', '180'),
(27, 'password_days_to_notify', '14');

-- --------------------------------------------------------

--
-- Table structure for table `t31_customer`
--

CREATE TABLE `t31_customer` (
  `customer_id` int(11) NOT NULL,
  `merge_id` int(11) NOT NULL,
  `ssn` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `country_code` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `address_2` text NOT NULL,
  `dob` date DEFAULT NULL,
  `player_club` varchar(100) NOT NULL,
  `id_type` varchar(250) NOT NULL,
  `id_state` varchar(250) NOT NULL,
  `id_number` varchar(250) NOT NULL,
  `id_expire` date DEFAULT NULL,
  `customer_image` varchar(500) NOT NULL,
  `id_image` varchar(500) NOT NULL,
  `id_image_2` varchar(500) NOT NULL,
  `id_type_2` varchar(500) NOT NULL,
  `id_state_2` varchar(250) NOT NULL,
  `id_number_2` varchar(250) NOT NULL,
  `id_expire_2` date DEFAULT NULL,
  `w9_image` varchar(500) NOT NULL,
  `w9_expiration` date DEFAULT NULL,
  `id_expired` tinyint(4) NOT NULL DEFAULT '0',
  `email` varchar(500) NOT NULL,
  `email_refused` tinyint(4) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `income` varchar(500) NOT NULL,
  `income_refused` tinyint(4) NOT NULL,
  `encrypted` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t31_customer_flag`
--

CREATE TABLE `t31_customer_flag` (
  `id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_id` int(11) NOT NULL,
  `game_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `t31_fields`
--

CREATE TABLE `t31_fields` (
  `field_id` int(11) NOT NULL,
  `field_name` varchar(100) NOT NULL,
  `field_format` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t31_fields`
--

INSERT INTO `t31_fields` (`field_id`, `field_name`, `field_format`) VALUES
(3, 'Location', 'select'),
(4, 'Machine/Ticket #', 'text'),
(5, 'Instrument Type', 'select'),
(6, 'Issuer', 'text'),
(7, 'Instrument #', 'text');

-- --------------------------------------------------------

--
-- Table structure for table `t31_field_value_list`
--

CREATE TABLE `t31_field_value_list` (
  `value_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `field_value` varchar(500) NOT NULL,
  `value_order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t31_merge_history`
--

CREATE TABLE `t31_merge_history` (
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `transaction_list` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t31_settings`
--

CREATE TABLE `t31_settings` (
  `setting_id` int(11) NOT NULL,
  `setting_name` varchar(250) NOT NULL,
  `setting_value` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t31_settings`
--

INSERT INTO `t31_settings` (`setting_id`, `setting_name`, `setting_value`) VALUES
(1, 'game_date_time', '6'),
(2, 'timeout', '45'),
(3, 'show_all_flagged', '0'),
(4, 'id_collection_threshold', '4000');

-- --------------------------------------------------------

--
-- Table structure for table `t31_transaction`
--

CREATE TABLE `t31_transaction` (
  `transaction_id` int(11) NOT NULL,
  `transaction_name` varchar(100) NOT NULL,
  `transaction_threshold` float(14,2) NOT NULL,
  `transaction_type` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t31_transaction_field`
--

CREATE TABLE `t31_transaction_field` (
  `transaction_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `field_order` int(11) NOT NULL,
  `threshold_only` tinyint(4) NOT NULL,
  `required_field` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t31_transaction_instance`
--

CREATE TABLE `t31_transaction_instance` (
  `instance_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `transaction_amount_in` float(15,2) NOT NULL,
  `transaction_amount_out` float(15,2) NOT NULL,
  `origin_customer_id` int(11) NOT NULL,
  `submitted_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t31_transaction_instance_field`
--

CREATE TABLE `t31_transaction_instance_field` (
  `instance_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `field_value` varchar(500) DEFAULT NULL,
  `field_order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `transaction_name` varchar(250) NOT NULL,
  `transaction_type` tinyint(4) NOT NULL,
  `form_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `transaction_status` tinyint(4) NOT NULL,
  `on_hold` tinyint(4) NOT NULL,
  `deposit_calculator` tinyint(4) NOT NULL,
  `require_documentation` tinyint(4) NOT NULL,
  `verify` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `transaction_name`, `transaction_type`, `form_id`, `account_id`, `transaction_status`, `on_hold`, `deposit_calculator`, `require_documentation`, `verify`) VALUES
(1, 'Deposit', 2, 9, 4, 1, 1, 1, 0, 0),
(2, 'Soft Count Drop', 1, 5, 14, 1, 0, 0, 1, 0),
(3, 'Kiosk 1 Fill', 2, 8, 7, 1, 0, 0, 1, 0),
(4, 'Kiosk 1 Return', 1, 7, 8, 1, 0, 0, 1, 0),
(5, 'ATM 2 Fill', 2, 8, 0, 1, 0, 0, 1, 0),
(6, 'ATM 2 Return', 1, 7, 0, 1, 0, 0, 1, 0),
(7, 'Return Open Bank', 1, 2, 13, 1, 0, 0, 0, 0),
(8, 'Tips - Vault Use Only', 1, 4, 17, 1, 0, 0, 1, 0),
(9, 'Kiosk 2 Fill', 2, 8, 9, 1, 0, 0, 1, 0),
(10, 'Kiosk 2 Return', 1, 7, 10, 1, 0, 0, 1, 0),
(11, 'Cash Exchange Receipt', 1, 4, 0, 1, 0, 0, 1, 0),
(12, 'Cash Exchange Disbursement', 2, 4, 0, 1, 0, 0, 1, 0),
(13, 'Tips - Cashier Use Only', 1, 4, 40, 1, 0, 0, 1, 1),
(14, 'Kiosk 3 Fill', 2, 8, 0, 0, 0, 0, 1, 0),
(15, 'Kiosk TP Fill', 2, 8, 0, 0, 0, 0, 1, 0),
(16, 'ATM TP Fill', 2, 8, 0, 1, 0, 0, 1, 0),
(17, 'Kiosk 3 Return', 1, 7, 0, 0, 0, 0, 1, 0),
(18, 'Kiosk TP Return', 1, 7, 0, 0, 0, 0, 1, 0),
(19, 'ATM TP Return', 1, 7, 0, 1, 0, 0, 1, 0),
(20, 'Commission Drop', 1, 11, 0, 1, 0, 0, 1, 0),
(21, 'Players Pool Drop', 1, 12, 0, 1, 0, 0, 1, 0),
(22, 'Money Found', 1, 13, 6, 1, 0, 0, 1, 0),
(23, 'Miscellaneous Disbursement', 2, 15, 11, 1, 0, 0, 1, 0),
(24, 'Miscellaneous Receipt', 1, 14, 12, 1, 0, 0, 1, 0),
(25, 'Test Money Disbursement', 2, 17, 15, 1, 0, 0, 1, 0),
(26, 'Test Money Receipt', 1, 17, 15, 1, 0, 0, 1, 0),
(27, 'Vending Machine Tobacco', 1, 19, 0, 0, 0, 0, 1, 0),
(28, 'Vending Machine Non Tobacco', 1, 19, 0, 0, 0, 0, 1, 0),
(29, 'BlackJack Fill', 2, 20, 0, 1, 0, 0, 1, 0),
(30, 'BlackJack Credit', 1, 20, 0, 1, 0, 0, 1, 0),
(31, 'Change Order', 1, 4, 0, 1, 0, 0, 1, 0),
(32, 'Table Games Drop', 1, 16, 0, 1, 0, 0, 1, 0),
(33, 'ATM 1 Fill', 2, 8, 0, 1, 0, 0, 1, 0),
(34, 'ATM 1 Return', 1, 7, 0, 1, 0, 0, 1, 0),
(35, 'Vending Machine Fill', 2, 4, 5, 1, 0, 0, 1, 0),
(36, 'Vending Machine Return', 1, 4, 5, 1, 0, 0, 1, 0),
(37, 'Money Exchange', 2, 15, 3, 1, 0, 0, 1, 0),
(38, 'Money Exchange Receipt', 1, 14, 3, 1, 0, 0, 1, 0),
(39, 'Jackpot Check Received', 1, 14, 0, 1, 0, 0, 1, 0),
(40, 'User Deposit', 2, 4, 1, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `auth_type` varchar(50) DEFAULT NULL,
  `user_sid` varchar(100) NOT NULL,
  `bank_level` tinyint(4) NOT NULL,
  `override` tinyint(4) NOT NULL,
  `variance` tinyint(4) NOT NULL,
  `is_admin` tinyint(4) NOT NULL,
  `user_manage` tinyint(4) NOT NULL,
  `data_item_manage` tinyint(4) DEFAULT NULL,
  `form_manage` tinyint(4) NOT NULL,
  `bank_manage` tinyint(4) NOT NULL,
  `transaction_manage` tinyint(4) NOT NULL,
  `account_manage` tinyint(4) NOT NULL,
  `audit_manage` tinyint(4) DEFAULT NULL,
  `system_manage` tinyint(1) NOT NULL,
  `impress_manage` tinyint(1) NOT NULL,
  `report_manage` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `employee_id`, `username`, `name`, `password_hash`, `auth_type`, `user_sid`, `bank_level`, `override`, `variance`, `is_admin`, `user_manage`, `data_item_manage`, `form_manage`, `bank_manage`, `transaction_manage`, `account_manage`, `audit_manage`, `system_manage`, `impress_manage`, `report_manage`, `status`) VALUES
(1, 'supportAdmin', NULL, NULL, NULL, NULL, 'local_SupportAdmin', 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(2, 'VaultAdmin', NULL, NULL, NULL, NULL, 'local_VaultAdmin', 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1);

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `new_user_add_password_history` AFTER INSERT ON `user` FOR EACH ROW BEGIN
      IF (NEW.password_hash IS NOT NULL AND NEW.password_hash <> '') THEN
                INSERT INTO password_history (user_id,password_hash) VALUES(NEW.user_id,NEW.password_hash);
      END IF;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `user_add_password_history` AFTER UPDATE ON `user` FOR EACH ROW BEGIN
      IF (NEW.password_hash IS NOT NULL AND NEW.password_hash <> '') THEN
                INSERT INTO password_history (user_id,password_hash) VALUES(NEW.user_id,NEW.password_hash);
      END IF;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_permissions`
--

CREATE TABLE `user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `permission_level` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_permissions`
--

INSERT INTO `user_permissions` (`user_id`, `permission_id`, `permission_level`) VALUES
(1, 1, 0),
(1, 2, 0),
(1, 3, 0),
(1, 4, 1),
(1, 5, 1),
(1, 6, 1),
(1, 7, 1),
(1, 8, 1),
(1, 9, 1),
(1, 10, 1),
(1, 11, 1),
(1, 12, 1),
(1, 13, 0),
(1, 14, 0),
(1, 15, 1),
(1, 16, 0),
(1, 17, 0),
(1, 18, 0),
(1, 19, 0),
(1, 20, 0),
(1, 21, 0),
(1, 22, 0),
(1, 23, 0),
(1, 24, 0),
(2, 1, 0),
(2, 2, 0),
(2, 3, 0),
(2, 4, 1),
(2, 5, 2),
(2, 6, 0),
(2, 7, 0),
(2, 8, 0),
(2, 9, 0),
(2, 10, 0),
(2, 11, 0),
(2, 12, 1),
(2, 13, 0),
(2, 14, 0),
(2, 15, 1),
(2, 16, 0),
(2, 17, 0),
(2, 18, 0),
(2, 19, 0),
(2, 20, 0),
(2, 21, 0),
(2, 22, 0),
(2, 23, 0),
(2, 24, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `admin_log`
--
ALTER TABLE `admin_log`
  ADD PRIMARY KEY (`admin_log_id`);

--
-- Indexes for table `admin_log_category`
--
ALTER TABLE `admin_log_category`
  ADD PRIMARY KEY (`admin_log_category_id`);

--
-- Indexes for table `audit_activity`
--
ALTER TABLE `audit_activity`
  ADD PRIMARY KEY (`audit_activity_id`);

--
-- Indexes for table `audit_activity_instance`
--
ALTER TABLE `audit_activity_instance`
  ADD PRIMARY KEY (`audit_activity_instance_id`),
  ADD KEY `idx_request_ix` (`request_id`);

--
-- Indexes for table `audit_instance`
--
ALTER TABLE `audit_instance`
  ADD PRIMARY KEY (`audit_instance_id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`),
  ADD UNIQUE KEY `bank_name` (`bank_name`);

--
-- Indexes for table `bank_activity`
--
ALTER TABLE `bank_activity`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `bank_activity_log`
--
ALTER TABLE `bank_activity_log`
  ADD PRIMARY KEY (`bank_activity_log_id`);

--
-- Indexes for table `bank_category`
--
ALTER TABLE `bank_category`
  ADD PRIMARY KEY (`bank_category_id`);

--
-- Indexes for table `bank_default_detail`
--
ALTER TABLE `bank_default_detail`
  ADD PRIMARY KEY (`bank_id`,`data_item_id`);

--
-- Indexes for table `bank_instance`
--
ALTER TABLE `bank_instance`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `bank_instance_log`
--
ALTER TABLE `bank_instance_log`
  ADD PRIMARY KEY (`bank_instance_id`);

--
-- Indexes for table `bank_user`
--
ALTER TABLE `bank_user`
  ADD UNIQUE KEY `primarykey` (`bank_instance_id`,`user_id`),
  ADD UNIQUE KEY `primary_key` (`bank_instance_id`,`user_id`);

--
-- Indexes for table `data_item`
--
ALTER TABLE `data_item`
  ADD PRIMARY KEY (`data_item_id`);

--
-- Indexes for table `export`
--
ALTER TABLE `export`
  ADD PRIMARY KEY (`export_id`);

--
-- Indexes for table `file_type`
--
ALTER TABLE `file_type`
  ADD PRIMARY KEY (`file_type_id`);

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`form_id`);

--
-- Indexes for table `item_category`
--
ALTER TABLE `item_category`
  ADD PRIMARY KEY (`item_category_id`);

--
-- Indexes for table `login_log`
--
ALTER TABLE `login_log`
  ADD PRIMARY KEY (`login_log_id`);

--
-- Indexes for table `message_code`
--
ALTER TABLE `message_code`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `meta_data`
--
ALTER TABLE `meta_data`
  ADD PRIMARY KEY (`meta_id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `version` (`version`);

--
-- Indexes for table `password_history`
--
ALTER TABLE `password_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `t31_customer`
--
ALTER TABLE `t31_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `t31_customer_flag`
--
ALTER TABLE `t31_customer_flag`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_date` (`customer_id`,`game_date`);

--
-- Indexes for table `t31_fields`
--
ALTER TABLE `t31_fields`
  ADD PRIMARY KEY (`field_id`);

--
-- Indexes for table `t31_field_value_list`
--
ALTER TABLE `t31_field_value_list`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `t31_settings`
--
ALTER TABLE `t31_settings`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `t31_transaction`
--
ALTER TABLE `t31_transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `t31_transaction_field`
--
ALTER TABLE `t31_transaction_field`
  ADD UNIQUE KEY `myindex` (`transaction_id`,`field_id`);

--
-- Indexes for table `t31_transaction_instance`
--
ALTER TABLE `t31_transaction_instance`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_sid` (`user_sid`),
  ADD UNIQUE KEY `id_user_sid` (`user_sid`),
  ADD UNIQUE KEY `idx_username` (`username`);

--
-- Indexes for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD UNIQUE KEY `ix_1` (`user_id`,`permission_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `admin_log`
--
ALTER TABLE `admin_log`
  MODIFY `admin_log_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `admin_log_category`
--
ALTER TABLE `admin_log_category`
  MODIFY `admin_log_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `audit_activity`
--
ALTER TABLE `audit_activity`
  MODIFY `audit_activity_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `audit_activity_instance`
--
ALTER TABLE `audit_activity_instance`
  MODIFY `audit_activity_instance_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `audit_instance`
--
ALTER TABLE `audit_instance`
  MODIFY `audit_instance_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `bank_activity`
--
ALTER TABLE `bank_activity`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bank_activity_log`
--
ALTER TABLE `bank_activity_log`
  MODIFY `bank_activity_log_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bank_category`
--
ALTER TABLE `bank_category`
  MODIFY `bank_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `bank_instance`
--
ALTER TABLE `bank_instance`
  MODIFY `instance_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `data_item`
--
ALTER TABLE `data_item`
  MODIFY `data_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
--
-- AUTO_INCREMENT for table `export`
--
ALTER TABLE `export`
  MODIFY `export_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `file_type`
--
ALTER TABLE `file_type`
  MODIFY `file_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `form_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `item_category`
--
ALTER TABLE `item_category`
  MODIFY `item_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `login_log`
--
ALTER TABLE `login_log`
  MODIFY `login_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `message_code`
--
ALTER TABLE `message_code`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;
--
-- AUTO_INCREMENT for table `meta_data`
--
ALTER TABLE `meta_data`
  MODIFY `meta_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `migration`
--
ALTER TABLE `migration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `password_history`
--
ALTER TABLE `password_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1008;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `t31_customer`
--
ALTER TABLE `t31_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t31_customer_flag`
--
ALTER TABLE `t31_customer_flag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t31_fields`
--
ALTER TABLE `t31_fields`
  MODIFY `field_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `t31_field_value_list`
--
ALTER TABLE `t31_field_value_list`
  MODIFY `value_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t31_settings`
--
ALTER TABLE `t31_settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `t31_transaction`
--
ALTER TABLE `t31_transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t31_transaction_instance`
--
ALTER TABLE `t31_transaction_instance`
  MODIFY `instance_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
